NR Lifestyle Store V4

Features included:
- Product name, price, image
- Search + category filters + sorting
- Cart + quantity controls
- Wishlist (saved in browser)
- Product details + rating (saved in browser)
- New/Offer badges
- Checkout/order form
- Dhaka/outside-Dhaka delivery charge
- bKash/Nagad instructions
- WhatsApp order + Order ID
- Contact + Facebook/Instagram/WhatsApp buttons
- Dark mode
- Home / Shop / About / Delivery / Contact sections
- Mobile-friendly design

Important:
- This is a static GitHub Pages site; it does not process real online payments.
- Replace demo products/images with your real products in index.html.
- Replace Facebook/Instagram links with your own page/profile URLs.
- Real admin panel, database, stock management, customer accounts and secure payment gateway need a backend/database or external service.
